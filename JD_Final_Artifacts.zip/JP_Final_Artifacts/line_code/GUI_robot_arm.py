import os
from tkinter import *

def straight_call():
        os.system('angle_maker.py')

def G0_call():
        date = ""
def G1_call():
        date = ""
def G90_call():
        date = ""
def G91_call():
        date = ""
def G20_call():
        date = ""
def G21_call():
        date = ""
def M2_call():
        date = ""
def M6_call():
        date = ""
def M72_call():
        date = ""
def first_call():
        date = ""
def second_call():
        date = ""
def third_call():
        date = ""
class App(Tk):
	def __init__(self, *args, **kwargs):
		Tk.__init__(self, *args, **kwargs)
		#Setup Menu
		MainMenu(self)
		#Setup Frame
		container = Frame(self)
		#self.geometry("100x100")
		container.pack(side="top", fill="both", expand=True)
		container.grid_rowconfigure(0, weight=1)
		container.grid_columnconfigure(0, weight=1)

		self.frames = {}

		for F in (StartPage, PageOne, PageTwo,PageThree):
			frame = F(container, self)
			self.frames[F] = frame
			frame.grid(row=0, column=0, sticky="nsew")

		self.show_frame(StartPage)	
	def show_frame(self, context):
		frame = self.frames[context]
		frame.tkraise()

class StartPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="Welcome To Our Robot Arm", font=("Arial Bold", 30))
		label.pack(padx=100, pady=100)
		page_one = Button(self, text="Straight line", font=("Arial Bold", 10), command=lambda:controller.show_frame(PageOne))
		page_one.pack()
		page_two = Button(self, text="Coin Sort", font=("Arial Bold", 10), command=lambda:controller.show_frame(PageTwo))
		page_two.pack()
		page_three = Button(self, text="G-Code Examples", font=("Arial Bold", 10), command=lambda:controller.show_frame(PageThree))
		page_three.pack()
		

class PageOne(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="Straight line", font=("Arial Bold", 30))
		label.pack(padx=100, pady=100)

		draw_straight_line = Button(self, text="Apply", font=("Arial Bold", 10), command = straight_call)
		draw_straight_line.pack()
		
		start_page = Button(self, text="Back to Main Menu", font=("Arial Bold", 10), command=lambda:controller.show_frame(StartPage))
		start_page.pack()

class PageTwo(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="Coin Sort", font=("Arial Bold", 30))
		label.pack(padx=100, pady=100)

		
		#rad1 = Radiobutton(self,text='First Layer', value=1)
		#rad2 = Radiobutton(self,text='Second Layer', value=2)
		#rad3 = Radiobutton(self,text='Third Layer', value=3)
		#rad1.pack()
		#rad2.pack()
		#rad3.pack()
		
		FIrst_layer = Button(self, text="FIrst_layer", font=("Arial Bold", 10), command = first_call)#no command since the functionality isn't complete
		FIrst_layer.pack()
		Second_layer = Button(self, text="Second_layer", font=("Arial Bold", 10), command = second_call)#no command since the functionality isn't complete
		Second_layer.pack()
		Third_layer = Button(self, text="Third_layer", font=("Arial Bold", 10), command = third_call)#no command since the functionality isn't complete
		Third_layer.pack()
		

		#coin_sort = Button(self, text="Apply", font=("Arial Bold", 10))#no command since the functionality isn't complete
		#coin_sort.pack()
		
		start_page = Button(self, text="Back to Main Menu", font=("Arial Bold", 10), command=lambda:controller.show_frame(StartPage))
		start_page.pack()
	
class PageThree(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="G-code Examples", font=("Arial Bold", 50))
		label.pack(padx=100, pady=100)
		
		G0 = Button(self, text="G0", font=("Arial Bold", 10), command=G0_call)
		G0.pack()
		G1 = Button(self, text="G1", font=("Arial Bold", 10), command=G1_call)
		G1.pack()
		G90 = Button(self, text="G90", font=("Arial Bold", 10), command=G90_call)
		G90.pack()
		G91 = Button(self, text="G91", font=("Arial Bold", 10), command=G91_call)
		G91.pack()
		G20 = Button(self, text="G20", font=("Arial Bold", 10), command=G20_call)
		G20.pack()
		G21 = Button(self, text="G21", font=("Arial Bold", 10), command=G21_call)
		G21.pack()
		M2 = Button(self, text="M2", font=("Arial Bold", 10), command=M2_call)
		M2.pack()
		M6 = Button(self, text="M6", font=("Arial Bold", 10), command=M6_call)
		M6.pack()
		M72 = Button(self, text="M72", font=("Arial Bold", 10), command=M72_call)
		M72.pack()
		
		start_page = Button(self, text="Back to Main Menu", font=("Arial Bold", 10), command=lambda:controller.show_frame(StartPage))
		start_page.pack()
		
class MainMenu:
	def __init__(self, master):
		menubar = Menu(master)
		filemenu = Menu(menubar, tearoff=0)
		filemenu.add_command(label="Exit", command=master.quit)
		menubar.add_cascade(label="File", menu=filemenu)
		master.config(menu=menubar)


app = App()
app.mainloop()
