import pandas as pd
df = pd.read_csv('straight_line_angles.csv')
print(df)
