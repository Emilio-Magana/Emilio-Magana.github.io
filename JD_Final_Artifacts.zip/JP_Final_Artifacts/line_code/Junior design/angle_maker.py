import math
import sys


#These are the values to the robot arm
upper_arm = 142.00
forearm = 198.00
inner_radius = 138
#the RObot is Right Handed
segment_len = 10      #take this down to 5 or 6 to meet the requrement
                      #of keeping it within the requirements
m_name = "Robot Arm"
###################################s####

try:
    t = open("targets.txt","r")
except:
    sys.exit("File 'targets.txt' is missing, please read included "+
             "instructions and try again")

targets = t.readlines()

# Converts the linear feedrate from mm/min to deg/min, and scales
# based on location. x1, y1 are the initial coordinates, x2, y2 are the end
# coordinates, F is the linear feedrate, settings contains the settings for
# the machine.
def find_feedrate(x1,x2,y1,y2,F):
    a = upper_arm # Length of the upper arm/vector a
    b = forearm   # Length of the forearm/vector b

    dist = math.sqrt((x2-x1)**2+(y2-y1)**2) # Distance between the two coords.
    x_dot = (x2-x1)/dist*F # Linear velocity in the x direction
    y_dot = (y2-y1)/dist*F # Linear velocity in the y direction
    d = math.sqrt(x1**2+y1**2) # Length of vector C (From shoulder to coord 1)
    d_dot = (x1*x_dot+y1*y_dot)/math.sqrt(x1**2+y1**2) # Rate of change of the 
                                                       # length of vector c
                                                       
    omega_d = (x1*y_dot-y1*x_dot)/d**2                 # Angular rate of change of
                                                       # vector c
                                                       
    omega_a = (omega_d + d_dot*(2*d**2*a-d**2-a**2+b**2)/(2*d**2*a**2)*
              math.sqrt(1-(d**2+a**2-b**2)/(2*d*a)))   # Angular rate of change 
                                                       # of the upper arm
                                                       
    omega_b = (omega_d - d_dot*(2*d**2*b-d**2-b**2+a**2)/(2*d**2*b**2)*
              math.sqrt(1-(d**2+b**2-a**2)/(2*d*b)))   # Angular rate of change
                                                       # of the forearm
                                                       
    omega = math.sqrt(omega_a**2+omega_b**2)           # Sum the squares of the angular
                                                       # feedrates.
                                                       
    return abs (math.degrees(omega))

# Determines the required angles of each motor in order to set the end
# at the proper position. x,y are the coordinates in the cartesian system,
# settings contains the settings of the machine, and name is the name of the
# gcode file being analyzed.
def find_angles(x,y,file_name):
    a = upper_arm           #142, LS
    b = forearm             #198, LE
    d = math.sqrt(x**2+y**2)
    rho = math.atan2(y,x)                               #thetaD
    
    try:
        theta = math.acos((x**2+y**2-a**2-b**2)/(2*a*b))#thetaB
        phi = rho - math.asin((b*math.sin(theta))/(d))  #thetaA
    except:
        sys.exit("File '%s.g' attempts to go outside of build area,"%file_name
                 + " please resize or rearrange and try again.")
    return[round(math.degrees(phi),0),round(math.degrees(theta),0)]

for file_name in targets:
    inner_rad = inner_radius
    gn = str(file_name)
    if gn.endswith("\n"):
        # Trims new-line characters
        gn = gn[:-1]
    if gn.endswith(".gcode"):
        # Trims the .gcode suffix to get the file name
        gn = gn[:-6]
    elif gn.endswith(".g"):
        # Trims the .g suffix to get the file name
        gn = gn[:-2]
    old_g = open(gn+".g","r")
    new_g = open(gn + "_angles.txt","w+")
    new_g.write("phi, theta\n")
    x_old = None    # Initializing x position variable
    y_old = None    # Initializing y position variable
    e_old = None    # Initializing extruder position variable
    f = None        # Initializing feedrate variable
    for line in old_g:
        arguments = line.upper().split()
        if line.upper().startswith("G0 ") or line.upper().startswith("G1 "):
            x_new = None
            y_new = None
            z_new = None
            e_new = None
            for coord in arguments:
                # Goes through the gcode line and stores important values
                if coord.upper().startswith("X"):
                    x_new = float(coord[1:].strip())
                elif coord.upper().startswith("Y"):
                    y_new = float(coord[1:].strip())+inner_rad
                    # The y offset is added in here for clarity in future
                    # calculations.
                elif coord.upper().startswith("F"):
                    f = float(coord[1:].strip())
            if x_new == None and y_new == None:
                code_line = arguments[0] + " "
                if f != None:
                    code_line += "F%f "%f
            elif x_old == None and y_old == None:
                [phi,theta] = find_angles(x_new,y_new,gn)
                code_line = "<%d, %d>"%(phi,theta)
                if f != None:
                    code_line += "F%f "%f
            else:
                if x_new == None:
                    x_new = x_old
                if y_new == None:
                    y_new = y_old
                x_mid = x_old
                y_mid = y_old
                e_mid = e_old
                movement = math.sqrt((x_new-x_mid)**2+(y_new-y_mid)**2)
                while movement > segment_len:
                    x_mid = x_mid + (x_new - x_mid)*segment_len/movement
                    y_mid = y_mid + (y_new - y_mid)*segment_len/movement
                    phiPrev = phi
                    thetaPrev = theta
                    [phi,theta] = find_angles(x_mid,y_mid,gn)
                    dPhi = phi-phiPrev
                    dTheta = theta - thetaPrev
                    code_line = "<%d, %d>" % (dPhi, dTheta)
                    #code_line = "G1 Phi:%f Theta:%f "%(phi, theta)
                    #if f != None:
                     #   omega = find_feedrate(x_mid,x_new,y_mid,
                      #                        y_new,f)
                       # code_line += "F(mm/min)%f "%omega
                    new_g.write(code_line.strip() + "\n")    
                    movement = math.sqrt((x_new-x_mid)**2+(y_new-y_mid)**2)
                phiPrev = phi
                thetaPrev = theta
                [phi,theta] = find_angles(x_new,y_new,gn)
                dPhi = phi-phiPrev
                dTheta = theta - thetaPrev
                code_line = "<%d, %d>"%(dPhi, dTheta)
                #if f != None:
                 #   omega = find_feedrate(x_mid,x_new,y_mid,y_new,f)
                  #  code_line += "F%f "%omega
            if x_new != None:
                x_old = x_new
            if y_new != None:
                y_old = y_new
            new_g.write(code_line.strip() + "\n")
        else:
            new_g.write(line.strip() + "\n")
    new_g.close()

#--------------------------------------------------------------------
import serial
baudrate = 9600
port = 'COM7'
arduinoData = serial.Serial(port, baudrate)

def waitForArduino():

    # wait until the Arduino sends 'Arduino Ready' - allows time for Arduino reset
    # it also ensures that any bytes left over from a previous message are discarded
    
    global Start, End
    
    msg = ""
    while msg.find("Arduino is ready") == -1:

        while ser.inWaiting() == 0:
            pass
        
        msg = recvFromArduino()

        print (msg) # python3 requires parenthesis
        print ()

#import pandas as pd
#df = pd.read_csv("straight_line_angles.txt")
#for rows in df.itertuples():
#    print(rows[2])
    
    
    

