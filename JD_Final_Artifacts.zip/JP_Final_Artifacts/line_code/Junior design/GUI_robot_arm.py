import os
from tkinter import *

def straight_call():
        os.system('gcode_translator_final.py')

class App(Tk):
	def __init__(self, *args, **kwargs):
		Tk.__init__(self, *args, **kwargs)
		#Setup Menu
		MainMenu(self)
		#Setup Frame
		container = Frame(self)
		#self.geometry("100x100")
		container.pack(side="top", fill="both", expand=True)
		container.grid_rowconfigure(0, weight=1)
		container.grid_columnconfigure(0, weight=1)

		self.frames = {}

		for F in (StartPage, PageOne, PageTwo,):
			frame = F(container, self)
			self.frames[F] = frame
			frame.grid(row=0, column=0, sticky="nsew")

		self.show_frame(StartPage)	
	def show_frame(self, context):
		frame = self.frames[context]
		frame.tkraise()

class StartPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="Welcome To Our Robot Arm", font=("Arial Bold", 30))
		label.pack(padx=100, pady=100)
		page_one = Button(self, text="Straight line", font=("Arial Bold", 10), command=lambda:controller.show_frame(PageOne))
		page_one.pack()
		page_two = Button(self, text="Coin Sort", font=("Arial Bold", 10), command=lambda:controller.show_frame(PageTwo))
		page_two.pack()
		"""
		page_three = Button(self, text="IDLE", font=("Arial Bold", 10), command=lambda:controller.show_frame(PageThree))
		page_three.pack()
		"""

class PageOne(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="Straight line", font=("Arial Bold", 30))
		label.pack(padx=100, pady=100)

		draw_straight_line = Button(self, text="Apply", font=("Arial Bold", 10), command = straight_call)
		draw_straight_line.pack()
		
		start_page = Button(self, text="Back to Main Menu", font=("Arial Bold", 10), command=lambda:controller.show_frame(StartPage))
		start_page.pack()

class PageTwo(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="Coin Sort", font=("Arial Bold", 30))
		label.pack(padx=100, pady=100)

		
		rad1 = Radiobutton(self,text='First Layer', value=1)
		rad2 = Radiobutton(self,text='Second Layer', value=2)
		rad3 = Radiobutton(self,text='Third Layer', value=3)
		rad1.pack()
		rad2.pack()
		rad3.pack()

		

		coin_sort = Button(self, text="Apply", font=("Arial Bold", 10))#no command since the functionality isn't complete
		coin_sort.pack()
		
		start_page = Button(self, text="Back to Main Menu", font=("Arial Bold", 10), command=lambda:controller.show_frame(StartPage))
		start_page.pack()
"""	
class PageThree(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent)

		label = Label(self, text="IDLING", font=("Arial Bold", 50))
		label.pack(padx=100, pady=100)
		start_page = Button(self, text="Back to Main Menu", font=("Arial Bold", 10), command=lambda:controller.show_frame(StartPage))
		start_page.pack()
"""		
class MainMenu:
	def __init__(self, master):
		menubar = Menu(master)
		filemenu = Menu(menubar, tearoff=0)
		filemenu.add_command(label="Exit", command=master.quit)
		menubar.add_cascade(label="File", menu=filemenu)
		master.config(menu=menubar)


app = App()
app.mainloop()
